CREATE DATABASE IF NOT EXISTS touristique;
USE touristique;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  gender VARCHAR(16),
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  national_id VARCHAR(100),
  email VARCHAR(150) NOT NULL UNIQUE,
  phone_number VARCHAR(50),
  birth_date DATE,
  is_foreign TINYINT(1) DEFAULT 0,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS trips (
  id INT AUTO_INCREMENT PRIMARY KEY,
  trip_code VARCHAR(32) NOT NULL UNIQUE,
  origin VARCHAR(100) NOT NULL,
  destination VARCHAR(100) NOT NULL,
  departure_time TIME NOT NULL,
  price DECIMAL(10, 2) NOT NULL DEFAULT 18000.00,
  seats_total INT NOT NULL DEFAULT 5,
  seats_available INT NOT NULL DEFAULT 5,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  trip_id INT NOT NULL,
  payment_method VARCHAR(100) NOT NULL,
  price_paid DECIMAL(10, 2) NOT NULL,
  travel_date DATE NOT NULL,
  status ENUM('ACTIVE', 'CANCELLED') DEFAULT 'ACTIVE',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reservation_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_reservation_trip FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE
);

INSERT INTO trips (trip_code, origin, destination, departure_time, price, seats_total, seats_available)
VALUES
  ('DO-YA-0300', 'Douala', 'Yaoundé', '03:00', 18000, 5, 5),
  ('DO-YA-0400', 'Douala', 'Yaoundé', '04:00', 18000, 5, 5),
  ('DO-YA-0500', 'Douala', 'Yaoundé', '05:00', 18000, 5, 5),
  ('DO-YA-0630', 'Douala', 'Yaoundé', '06:30', 18000, 5, 5),
  ('DO-YA-0830', 'Douala', 'Yaoundé', '08:30', 18000, 5, 5),
  ('DO-YA-1000', 'Douala', 'Yaoundé', '10:00', 18000, 5, 5),
  ('DO-YA-1100', 'Douala', 'Yaoundé', '11:00', 18000, 5, 5),
  ('DO-YA-1200', 'Douala', 'Yaoundé', '12:00', 18000, 5, 5),
  ('DO-YA-1300', 'Douala', 'Yaoundé', '13:00', 18000, 5, 5),
  ('DO-YA-1400', 'Douala', 'Yaoundé', '14:00', 18000, 5, 5),
  ('DO-YA-1530', 'Douala', 'Yaoundé', '15:30', 18000, 5, 5),
  ('DO-YA-1700', 'Douala', 'Yaoundé', '17:00', 18000, 5, 5),
  ('DO-YA-1900', 'Douala', 'Yaoundé', '19:00', 18000, 5, 5),
  ('YA-DO-0300', 'Yaoundé', 'Douala', '03:00', 18000, 5, 5),
  ('YA-DO-0400', 'Yaoundé', 'Douala', '04:00', 18000, 5, 5),
  ('YA-DO-0500', 'Yaoundé', 'Douala', '05:00', 18000, 5, 5),
  ('YA-DO-0630', 'Yaoundé', 'Douala', '06:30', 18000, 5, 5),
  ('YA-DO-0830', 'Yaoundé', 'Douala', '08:30', 18000, 5, 5),
  ('YA-DO-1000', 'Yaoundé', 'Douala', '10:00', 18000, 5, 5),
  ('YA-DO-1100', 'Yaoundé', 'Douala', '11:00', 18000, 5, 5),
  ('YA-DO-1200', 'Yaoundé', 'Douala', '12:00', 18000, 5, 5),
  ('YA-DO-1300', 'Yaoundé', 'Douala', '13:00', 18000, 5, 5),
  ('YA-DO-1400', 'Yaoundé', 'Douala', '14:00', 18000, 5, 5),
  ('YA-DO-1530', 'Yaoundé', 'Douala', '15:30', 18000, 5, 5),
  ('YA-DO-1700', 'Yaoundé', 'Douala', '17:00', 18000, 5, 5),
  ('YA-DO-1900', 'Yaoundé', 'Douala', '19:00', 18000, 5, 5)
ON DUPLICATE KEY UPDATE price = VALUES(price);

