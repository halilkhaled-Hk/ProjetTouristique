const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const mysql = require('mysql2/promise');
const { generateTicketPdf, sendTicketEmail } = require('./utils/ticket');

const PORT = process.env.PORT || 5000;
const DB_CONFIG = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'raptor',
  database: process.env.DB_NAME || 'touristique',
  waitForConnections: true,
  connectionLimit: 10,
  timezone: 'Z'
};

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const pool = mysql.createPool(DB_CONFIG);

const TRIP_SCHEDULES = [
  '03:00',
  '04:00',
  '05:00',
  '06:30',
  '08:30',
  '10:00',
  '11:00',
  '12:00',
  '13:00',
  '14:00',
  '15:30',
  '17:00',
  '19:00'
];

const BASE_ROUTES = [
  { origin: 'Douala', destination: 'Yaoundé', price: 18000 },
  { origin: 'Yaoundé', destination: 'Douala', price: 18000 }
];

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@gmail.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const ADMIN_TOKENS = new Set();

const sanitizeUser = (row) => ({
  id: row.id,
  gender: row.gender,
  firstName: row.first_name,
  lastName: row.last_name,
  nationalId: row.national_id,
  email: row.email,
  phoneNumber: row.phone_number,
  birthDate: row.birth_date ? row.birth_date.toISOString().split('T')[0] : null,
  isForeign: !!row.is_foreign,
  createdAt: row.created_at ? row.created_at.toISOString() : null
});

const authenticateAdmin = (req, res, next) => {
  const token = req.headers['x-admin-token'];
  if (!token || !ADMIN_TOKENS.has(token)) {
    return res.status(401).json({ message: 'Authentification administrateur requise.' });
  }
  req.adminToken = token;
  next();
};

async function seedTrips() {
  const connection = await pool.getConnection();
  try {
    for (const route of BASE_ROUTES) {
      for (const time of TRIP_SCHEDULES) {
        const code = `${route.origin.slice(0, 2).toUpperCase()}-${route.destination
          .slice(0, 2)
          .toUpperCase()}-${time.replace(':', '')}`;
        await connection.query(
          `INSERT IGNORE INTO trips (trip_code, origin, destination, departure_time, price, seats_total, seats_available)
           VALUES (?, ?, ?, ?, ?, 5, 5)`,
          [code, route.origin, route.destination, time, route.price]
        );
      }
    }
    console.log('✔️ Trajets de démonstration disponibles');
  } catch (error) {
    console.error('Erreur lors du seed des trajets:', error.message);
  } finally {
    connection.release();
  }
}

app.get('/', (_req, res) => {
  res.json({ status: 'Touristique Express API opérationnelle' });
});

app.post('/api/auth/signup', async (req, res) => {
  const {
    gender,
    firstName,
    lastName,
    nationalId,
    email,
    phoneNumber,
    birthDate,
    password,
    isForeign
  } = req.body;

  if (!firstName || !lastName || !email || !password) {
    return res.status(400).json({ message: 'Merci de renseigner au minimum nom, prénom, email et mot de passe.' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      `INSERT INTO users (gender, first_name, last_name, national_id, email, phone_number, birth_date, is_foreign, password_hash)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        gender || null,
        firstName,
        lastName,
        nationalId || null,
        email.toLowerCase(),
        phoneNumber || null,
        birthDate || null,
        isForeign ? 1 : 0,
        hashedPassword
      ]
    );

    const [rows] = await pool.query('SELECT * FROM users WHERE id = ?', [result.insertId]);
    return res.status(201).json({ user: sanitizeUser(rows[0]) });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'Un compte existe déjà avec cet email.' });
    }
    console.error('Erreur inscription:', error);
    return res.status(500).json({ message: 'Impossible de créer le compte.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Email et mot de passe requis.' });
  }

  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
    if (!rows.length) {
      return res.status(401).json({ message: 'Identifiants invalides.' });
    }
    const userRow = rows[0];
    const validPassword = await bcrypt.compare(password, userRow.password_hash);
    if (!validPassword) {
      return res.status(401).json({ message: 'Identifiants invalides.' });
    }
    return res.json({ user: sanitizeUser(userRow) });
  } catch (error) {
    console.error('Erreur connexion:', error);
    return res.status(500).json({ message: 'Connexion impossible pour le moment.' });
  }
});

app.get('/api/trips', async (_req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM trips ORDER BY departure_time ASC');
    res.json(rows);
  } catch (error) {
    console.error('Erreur récupération trajets:', error);
    res.status(500).json({ message: 'Impossible de charger les trajets.' });
  }
});

app.post('/api/reservations', async (req, res) => {
  const { userId, tripId, paymentMethod, travelDate } = req.body;
  if (!userId || !tripId || !paymentMethod || !travelDate) {
    return res.status(400).json({ message: 'Utilisateur, voyage, date et mode de paiement sont requis.' });
  }

  const normalizedDate = new Date(travelDate);
  if (Number.isNaN(normalizedDate.getTime())) {
    return res.status(400).json({ message: 'Date de voyage invalide.' });
  }
  const mysqlDate = normalizedDate.toISOString().split('T')[0];

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [tripRows] = await connection.query('SELECT * FROM trips WHERE id = ? FOR UPDATE', [tripId]);
    if (!tripRows.length) {
      await connection.rollback();
      return res.status(404).json({ message: 'Voyage introuvable.' });
    }
    const trip = tripRows[0];
    if (trip.seats_available <= 0) {
      await connection.rollback();
      return res.status(400).json({ message: 'Ce voyage est complet.' });
    }

    const departureDateTime = new Date(`${mysqlDate}T${trip.departure_time}`);
    if (Number.isNaN(departureDateTime.getTime())) {
      await connection.rollback();
      return res.status(400).json({ message: 'Horaire de voyage incorrect.' });
    }
    if (departureDateTime <= new Date()) {
      await connection.rollback();
      return res.status(400).json({ message: 'Impossible de réserver pour un horaire déjà passé.' });
    }

    const [insertResult] = await connection.query(
      `INSERT INTO reservations (user_id, trip_id, payment_method, price_paid, status, travel_date)
       VALUES (?, ?, ?, ?, 'ACTIVE', ?)`,
      [userId, tripId, paymentMethod, trip.price, mysqlDate]
    );
    await connection.query('UPDATE trips SET seats_available = seats_available - 1 WHERE id = ?', [tripId]);
    const [reservationRows] = await pool.query(
      `SELECT r.id,
              r.payment_method,
              r.price_paid,
              r.status,
              r.created_at,
              r.travel_date,
              t.origin,
              t.destination,
              t.departure_time,
              t.seats_available,
              t.seats_total,
              u.first_name,
              u.last_name,
              u.email,
              CONCAT(UPPER(LEFT(t.origin, 2)), '-', UPPER(LEFT(t.destination, 2)), '-', LPAD(r.id, 5, '0')) AS ticket_code
       FROM reservations r
       INNER JOIN trips t ON r.trip_id = t.id
       INNER JOIN users u ON r.user_id = u.id
       WHERE r.id = ?`,
      [insertResult.insertId]
    );

    const reservationDetails = reservationRows[0];

    try {
      const pdfBuffer = await generateTicketPdf({ reservation: reservationDetails });
      await sendTicketEmail({ reservation: reservationDetails, ticketBuffer: pdfBuffer });
    } catch (ticketError) {
      console.error('Impossible de générer ou d\'envoyer le billet:', ticketError.message);
    }

    res.status(201).json({ message: 'Réservation confirmée.', reservation: reservationDetails });
  } catch (error) {
    await connection.rollback();
    console.error('Erreur réservation:', error);
    res.status(500).json({ message: 'Impossible de finaliser la réservation.' });
  } finally {
    connection.release();
  }
});

app.get('/api/reservations', async (req, res) => {
  const { userId } = req.query;
  if (!userId) {
    return res.status(400).json({ message: 'Identifiant utilisateur requis.' });
  }

  try {
    const [rows] = await pool.query(
      `SELECT r.id, r.status, r.payment_method, r.created_at, r.price_paid, r.travel_date,
              t.origin, t.destination, t.departure_time
       FROM reservations r
       INNER JOIN trips t ON r.trip_id = t.id
       WHERE r.user_id = ?
       ORDER BY r.created_at DESC`,
      [userId]
    );
    res.json(rows);
  } catch (error) {
    console.error('Erreur récupération réservations:', error);
    res.status(500).json({ message: 'Impossible de charger vos réservations.' });
  }
});

app.delete('/api/reservations/:reservationId', async (req, res) => {
  const { reservationId } = req.params;
  const { userId } = req.query;

  if (!userId) {
    return res.status(400).json({ message: 'Utilisateur requis pour annuler.' });
  }

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [rows] = await connection.query(
      'SELECT * FROM reservations WHERE id = ? AND user_id = ? FOR UPDATE',
      [reservationId, userId]
    );
    if (!rows.length) {
      await connection.rollback();
      return res.status(404).json({ message: 'Réservation introuvable.' });
    }
    const reservation = rows[0];

    await connection.query('DELETE FROM reservations WHERE id = ?', [reservationId]);
    await connection.query(
      'UPDATE trips SET seats_available = LEAST(seats_total, seats_available + 1) WHERE id = ?',
      [reservation.trip_id]
    );
    await connection.commit();

    res.json({ message: 'Réservation supprimée.' });
  } catch (error) {
    await connection.rollback();
    console.error('Erreur annulation:', error);
    res.status(500).json({ message: 'Impossible d\'annuler pour le moment.' });
  } finally {
    connection.release();
  }
});

app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ message: 'Identifiants administrateur invalides.' });
  }
  const token = crypto.randomUUID();
  ADMIN_TOKENS.add(token);
  res.json({ token });
});

app.post('/api/admin/logout', authenticateAdmin, (req, res) => {
  ADMIN_TOKENS.delete(req.adminToken);
  res.json({ message: 'Déconnexion effectuée.' });
});

app.get('/api/admin/reservations', authenticateAdmin, async (_req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT r.id,
              r.status,
              r.payment_method,
              r.price_paid,
              r.travel_date,
              r.created_at,
              t.origin,
              t.destination,
              t.departure_time,
              u.first_name,
              u.last_name,
              u.email,
              u.phone_number
       FROM reservations r
       INNER JOIN trips t ON r.trip_id = t.id
       INNER JOIN users u ON r.user_id = u.id
       ORDER BY r.created_at DESC`
    );
    res.json(rows);
  } catch (error) {
    console.error('Erreur récupération réservations admin:', error);
    res.status(500).json({ message: 'Impossible de charger les réservations.' });
  }
});

app.use((req, res) => {
  res.status(404).json({ message: `Route ${req.path} introuvable.` });
});

seedTrips().catch((err) => console.error('Impossible de préparer les trajets:', err.message));

app.listen(PORT, () => {
  console.log(`🚍 Touristique Express API - port ${PORT}`);
});
