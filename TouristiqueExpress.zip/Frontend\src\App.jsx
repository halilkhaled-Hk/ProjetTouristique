import { useCallback, useEffect, useMemo, useState } from 'react';
import './App.css';
import logo from './assets/prestige-logo.png';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000';
const PAYMENT_METHODS = ['Mobile Money', 'Carte bancaire', 'Espèces'];
const ROUTES = [
  { id: 'dy', label: 'Douala → Yaoundé', origin: 'Douala', destination: 'Yaoundé' },
  { id: 'yd', label: 'Yaoundé → Douala', origin: 'Yaoundé', destination: 'Douala' }
];

const formatTime = (time) => {
  if (!time) return '';
  const [hour, minute] = time.split(':');
  return `${hour}h${minute}`;
};

const formatPrice = (value) =>
  new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XAF' }).format(Number(value || 0));

const formatDate = (value) => (value ? new Date(value).toLocaleDateString('fr-FR') : '');

const isDeparturePast = (trip, travelDate) => {
  if (!travelDate) return false;
  const departureDate = new Date(travelDate);
  if (Number.isNaN(departureDate.getTime())) return false;
  const today = new Date();

  const tripTime = trip.departure_time?.slice(0, 5) || '00:00';
  const [hours, minutes] = tripTime.split(':').map(Number);
  departureDate.setHours(hours, minutes, 0, 0);

  return departureDate <= today;
};

const emptySignup = {
  gender: 'Femme',
  firstName: '',
  lastName: '',
  nationalId: '',
  email: '',
  phoneNumber: '',
  birthDate: '',
  password: '',
  confirmPassword: '',
  isForeign: false
};

function AuthSection({ onSuccess }) {
  const [mode, setMode] = useState('login');
  const [signupData, setSignupData] = useState(emptySignup);
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);

  useEffect(() => {
    setFeedback(null);
    setLoading(false);
  }, [mode]);

  const updateSignup = (field, value) => setSignupData((prev) => ({ ...prev, [field]: value }));
  const updateLogin = (field, value) => setLoginData((prev) => ({ ...prev, [field]: value }));

  const handleSignup = async (event) => {
    event.preventDefault();
    if (signupData.password !== signupData.confirmPassword) {
      setFeedback({ type: 'error', text: 'Les mots de passe ne correspondent pas.' });
      return;
    }

    setLoading(true);
    setFeedback(null);
    try {
      const response = await fetch(`${API_BASE}/api/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gender: signupData.gender,
          firstName: signupData.firstName.trim(),
          lastName: signupData.lastName.trim(),
          nationalId: signupData.nationalId.trim(),
          email: signupData.email.trim().toLowerCase(),
          phoneNumber: signupData.phoneNumber.trim(),
          birthDate: signupData.birthDate,
          password: signupData.password,
          isForeign: signupData.isForeign
        })
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || 'Inscription impossible');
      }
      const data = await response.json();
      onSuccess(data.user);
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (event) => {
    event.preventDefault();
    setLoading(true);
    setFeedback(null);
    try {
      const response = await fetch(`${API_BASE}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: loginData.email.trim().toLowerCase(),
          password: loginData.password
        })
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || 'Connexion impossible');
      }
      const data = await response.json();
      onSuccess(data.user);
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-shell">
      {mode === 'login' ? (
        <div className="login-card">
          <img src={logo} alt="Prestige 777" className="login-logo" />
          <p className="login-greeting">Hello,</p>
          <h1>Welcome to Prestige Touristique</h1>
          <p className="login-subtitle">Veuillez vous connecter pour continuer.</p>

          {feedback && <div className={`feedback ${feedback.type}`}>{feedback.text}</div>}

          <form className="login-form" onSubmit={handleLogin}>
            <label>
              E-mail
              <input
                type="email"
                required
                value={loginData.email}
                onChange={(event) => updateLogin('email', event.target.value)}
                placeholder="client@prestige.cm"
              />
            </label>
            <label>
              Mot de passe
              <input
                type="password"
                required
                value={loginData.password}
                onChange={(event) => updateLogin('password', event.target.value)}
                placeholder="********"
              />
            </label>
            <div className="login-actions">
              <label className="remember">
                <input type="checkbox" defaultChecked readOnly />
                Remember Me
              </label>
              <button
                type="button"
                className="link-button"
                onClick={() => setFeedback({ type: 'info', text: 'Contactez Touristique Express pour réinitialiser votre mot de passe.' })}
              >
                Forgot your password?
              </button>
            </div>
            <button type="submit" className="primary wide" disabled={loading}>
              {loading ? 'Connexion...' : 'LOG IN'}
            </button>
          </form>

          <button type="button" className="secondary wide" onClick={() => setMode('signup')}>
            SIGN UP
          </button>
          <button
            type="button"
            className="tertiary wide"
            onClick={() => setFeedback({ type: 'info', text: 'Merci de vous connecter pour réserver un billet.' })}
          >
            CONTINUE WITHOUT SIGNING UP
          </button>
        </div>
      ) : (
        <div className="signup-surface">
          <button className="link-button back-link" onClick={() => setMode('login')}>
            ← Retour à la connexion
          </button>
          <form className="form" onSubmit={handleSignup}>
            <div className="signup-heading">
              <img src={logo} alt="Prestige 777" />
              <div>
                <p className="login-greeting">Hello,</p>
                <h2>Créez votre espace Prestige</h2>
              </div>
            </div>
            {feedback && <div className={`feedback ${feedback.type}`}>{feedback.text}</div>}
            <div className="gender-toggle">
              <button
                type="button"
                className={signupData.gender === 'Femme' ? 'active' : ''}
                onClick={() => updateSignup('gender', 'Femme')}
              >
                Femme
              </button>
              <button
                type="button"
                className={signupData.gender === 'Homme' ? 'active' : ''}
                onClick={() => updateSignup('gender', 'Homme')}
              >
                Homme
              </button>
            </div>
            <div className="inline-fields">
              <label>
                Prénom(s)
                <input
                  type="text"
                  required
                  value={signupData.firstName}
                  onChange={(event) => updateSignup('firstName', event.target.value)}
                  placeholder="ex: Danielle"
                />
              </label>
              <label>
                Nom
                <input
                  type="text"
                  required
                  value={signupData.lastName}
                  onChange={(event) => updateSignup('lastName', event.target.value)}
                  placeholder="ex: MBOG"
                />
              </label>
            </div>
            <label className="checkbox-row">
              <input
                type="checkbox"
                checked={signupData.isForeign}
                onChange={(event) => updateSignup('isForeign', event.target.checked)}
              />
              Je ne suis pas ressortissant camerounais
            </label>
            <label>
              Numéro de pièce (CNI / Passeport)
              <input
                type="text"
                value={signupData.nationalId}
                onChange={(event) => updateSignup('nationalId', event.target.value)}
                placeholder="ex: 123456789"
              />
            </label>
            <label>
              Email
              <input
                type="email"
                required
                value={signupData.email}
                onChange={(event) => updateSignup('email', event.target.value)}
              />
            </label>
            <label>
              Téléphone
              <input
                type="tel"
                value={signupData.phoneNumber}
                onChange={(event) => updateSignup('phoneNumber', event.target.value)}
                placeholder="+237 6 XX XX XX"
              />
            </label>
            <label>
              Date de naissance
              <input
                type="date"
                value={signupData.birthDate}
                onChange={(event) => updateSignup('birthDate', event.target.value)}
              />
            </label>
            <div className="inline-fields">
              <label>
                Mot de passe
                <input
                  type="password"
                  required
                  value={signupData.password}
                  onChange={(event) => updateSignup('password', event.target.value)}
                />
              </label>
              <label>
                Confirmation
                <input
                  type="password"
                  required
                  value={signupData.confirmPassword}
                  onChange={(event) => updateSignup('confirmPassword', event.target.value)}
                />
              </label>
            </div>
            <button type="submit" className="primary" disabled={loading}>
              {loading ? 'Création...' : "Créer mon espace"}
            </button>
            <p className="disclaimer">En continuant, vous acceptez la Politique de confidentialité Touristique Express.</p>
          </form>
        </div>
      )}
    </div>
  );
}

function AdminLogin({ onSuccess, onBack }) {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const updateField = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setFeedback(null);
    try {
      const response = await fetch(`${API_BASE}/api/admin/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email.trim().toLowerCase(), password: form.password })
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || 'Connexion impossible');
      }
      const data = await response.json();
      onSuccess(data.token);
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="login-card admin-card">
        <button className="link-button back-link" onClick={onBack}>
          ← Retour espace client
        </button>
        <img src={logo} alt="Prestige 777" className="login-logo" />
        <p className="login-greeting">Administration</p>
        <h1>Prestige Control Center</h1>
        <p className="login-subtitle">Veuillez vous identifier pour accéder aux réservations.</p>
        {feedback && <div className={`feedback ${feedback.type}`}>{feedback.text}</div>}
        <form className="login-form" onSubmit={handleSubmit}>
          <label>
            Email
            <input type="email" required value={form.email} onChange={(event) => updateField('email', event.target.value)} />
          </label>
          <label>
            Mot de passe
            <input
              type="password"
              required
              value={form.password}
              onChange={(event) => updateField('password', event.target.value)}
            />
          </label>
          <button type="submit" className="primary wide" disabled={loading}>
            {loading ? 'Connexion...' : 'Se connecter'}
          </button>
        </form>
      </div>
    </div>
  );
}

function TravelSearch({ onConfirm, onLogout, user }) {
  const [selectedRoute, setSelectedRoute] = useState(ROUTES[0]);
  const [travelDate, setTravelDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [passengers, setPassengers] = useState(1);

  return (
    <div className="search-shell">
      <header className="wizard-header">
        <img src={logo} alt="Prestige 777" />
        <div>
          <p>Bienvenue {user.firstName}</p>
          <small>Étape 1/3 — Sélection de votre trajet</small>
        </div>
        <button className="ghost" onClick={onLogout}>
          Déconnexion
        </button>
      </header>

      <div className="wizard-progress">
        <div className="wizard-step active">1<br />Select journey</div>
        <div className="wizard-step">2<br />Select seat</div>
        <div className="wizard-step">3<br />Payment</div>
      </div>

      <div className="search-card">
        <div className="search-field">
          <label>From/To</label>
          <div className="route-toggle">
            {ROUTES.map((route) => (
              <button
                key={route.id}
                className={selectedRoute.id === route.id ? 'active' : ''}
                onClick={() => setSelectedRoute(route)}
                type="button"
              >
                {route.label}
              </button>
            ))}
          </div>
        </div>

        <div className="search-row">
          <label>
            When
            <input type="date" value={travelDate} onChange={(event) => setTravelDate(event.target.value)} />
          </label>
          <label>
            Passengers
            <select value={passengers} onChange={(event) => setPassengers(Number(event.target.value))}>
              {[1, 2, 3, 4, 5].map((nb) => (
                <option key={nb} value={nb}>
                  {nb} Passager{nb > 1 ? 's' : ''}
                </option>
              ))}
            </select>
          </label>
        </div>

        <button
          className="primary wide"
          onClick={() =>
            onConfirm({
              origin: selectedRoute.origin,
              destination: selectedRoute.destination,
              date: travelDate,
              passengers
            })
          }
        >
          Search
        </button>
      </div>
    </div>
  );
}

function Dashboard({ user, onLogout, searchParams, onResetSearch }) {
  const [trips, setTrips] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [bookingTrip, setBookingTrip] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState(PAYMENT_METHODS[0]);
  const [status, setStatus] = useState(null);
  const [loadingTrips, setLoadingTrips] = useState(false);

  const fetchTrips = useCallback(async () => {
    setLoadingTrips(true);
    try {
      const response = await fetch(`${API_BASE}/api/trips`);
      if (!response.ok) {
        throw new Error('Impossible de charger les voyages.');
      }
      const data = await response.json();
      setTrips(data);
    } catch (error) {
      setStatus({ type: 'error', text: error.message });
    } finally {
      setLoadingTrips(false);
    }
  }, []);

  const fetchReservations = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE}/api/reservations?userId=${user.id}`);
      if (!response.ok) {
        throw new Error('Impossible de charger vos réservations.');
      }
      const data = await response.json();
      setReservations(data);
    } catch (error) {
      setStatus({ type: 'error', text: error.message });
    }
  }, [user.id]);

  useEffect(() => {
    fetchTrips();
    fetchReservations();
  }, [fetchTrips, fetchReservations]);

  useEffect(() => {
    if (!status) return undefined;
    const timer = setTimeout(() => setStatus(null), 4000);
    return () => clearTimeout(timer);
  }, [status]);

  const confirmBooking = async () => {
    if (!bookingTrip) return;
    if (isDeparturePast(bookingTrip, searchParams?.date)) {
      setStatus({ type: 'error', text: 'Cet horaire est déjà passé. Merci de choisir un autre départ.' });
      return;
    }
    try {
      const response = await fetch(`${API_BASE}/api/reservations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          tripId: bookingTrip.id,
          paymentMethod,
          travelDate: searchParams?.date || new Date().toISOString().split('T')[0]
        })
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || 'Réservation refusée');
      }
      setStatus({ type: 'success', text: 'Réservation confirmée 🎉' });
      setBookingTrip(null);
      fetchTrips();
      fetchReservations();
    } catch (error) {
      setStatus({ type: 'error', text: error.message });
    }
  };

  const cancelReservation = async (reservationId) => {
    try {
      const response = await fetch(
        `${API_BASE}/api/reservations/${reservationId}?userId=${user.id}`,
        { method: 'DELETE' }
      );
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || 'Annulation impossible');
      }
      setReservations((prev) => prev.filter((item) => item.id !== reservationId));
      setStatus({ type: 'info', text: 'Réservation annulée.' });
      fetchTrips();
    } catch (error) {
      setStatus({ type: 'error', text: error.message });
    }
  };

  const filteredTrips = useMemo(() => {
    if (!searchParams) return trips;
    return trips.filter(
      (trip) => trip.origin === searchParams.origin && trip.destination === searchParams.destination
    );
  }, [trips, searchParams]);

  return (
    <div className="dashboard">
      <header className="dashboard__header">
        <div className="identity">
          <img src={logo} alt="Prestige 777" />
          <div>
            <p>Bienvenue, {user.firstName} {user.lastName}</p>
            {searchParams && (
              <small>
                {searchParams.origin} → {searchParams.destination} | {formatDate(searchParams.date)}
              </small>
            )}
          </div>
        </div>
        <div className="header-actions">
          <button className="ghost" onClick={onResetSearch}>
            Modifier l&apos;itinéraire
          </button>
          <button className="ghost" onClick={onLogout}>
            Déconnexion
          </button>
        </div>
      </header>

      {status && <div className={`feedback ${status.type}`}>{status.text}</div>}

      <section className="trips-section">
        <div className="section-heading">
          <div>
            <h2>Voyages disponibles</h2>
            <p>
              {searchParams
                ? `${searchParams.origin} → ${searchParams.destination} — ${formatDate(searchParams.date)}`
                : 'Horaires inspirés de la grille Business Class.'}
            </p>
          </div>
          <button className="ghost" onClick={fetchTrips}>
            Rafraîchir
          </button>
        </div>

        <div className="trip-grid">
          {filteredTrips.length === 0 && !loadingTrips && <p>Aucun voyage pour l&apos;instant.</p>}
          {loadingTrips && <p>Chargement des voyages...</p>}
          {filteredTrips.map((trip) => {
            const isPast = isDeparturePast(trip, searchParams?.date);
            return (
              <article
                key={trip.id}
                className={`trip-card ${trip.seats_available === 0 || isPast ? 'disabled' : ''}`}
              >
                <div className="trip-card__time">{formatTime(trip.departure_time)}</div>
                <p className="trip-card__price">{formatPrice(trip.price)}</p>
                <p className="trip-card__seats">
                  {trip.seats_available} / {trip.seats_total} places
                </p>
                {isPast && <small className="trip-card__status">Départ dépassé</small>}
                <button
                  onClick={() => {
                    setBookingTrip(trip);
                    setPaymentMethod(PAYMENT_METHODS[0]);
                  }}
                  disabled={trip.seats_available === 0 || isPast}
                >
                  Réserver
                </button>
              </article>
            );
          })}
        </div>
      </section>

      <section className="reservations-section">
        <div className="section-heading">
          <h2>Mes réservations</h2>
        </div>
        {reservations.length === 0 ? (
          <p>Vous n&apos;avez pas encore de réservation active.</p>
        ) : (
          <div className="reservation-list">
            {reservations.map((res) => (
              <article key={res.id} className={`reservation-card status-${res.status.toLowerCase()}`}>
                <div>
                  <p className="reservation-route">
                    {res.origin} → {res.destination}
                  </p>
                  <p className="reservation-time">
                    {formatDate(res.travel_date)} • {formatTime(res.departure_time)}
                  </p>
                  <small>Payé : {formatPrice(res.price_paid)}</small>
                </div>
                <div className="reservation-meta">
                  <span className="badge">{res.status}</span>
                  <span>{res.payment_method}</span>
                  {res.status === 'ACTIVE' && (
                    <button className="ghost" onClick={() => cancelReservation(res.id)}>
                      Annuler
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {bookingTrip && (
        <div className="booking-modal">
          <div className="booking-card">
            <div className="booking-header">
              <h3>Confirmer votre billet</h3>
              <button className="ghost" onClick={() => setBookingTrip(null)}>
                Fermer
              </button>
            </div>
            <p className="booking-route">
              {bookingTrip.origin} → {bookingTrip.destination}
            </p>
            <p className="booking-time">{formatTime(bookingTrip.departure_time)}</p>
            <p className="booking-price">Total : {formatPrice(bookingTrip.price)}</p>

            <label>
              Mode de paiement
              <select value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value)}>
                {PAYMENT_METHODS.map((method) => (
                  <option key={method} value={method}>
                    {method}
                  </option>
                ))}
              </select>
            </label>
            <button className="primary" onClick={confirmBooking}>
              Confirmer et payer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function AdminDashboard({ token, onLogout }) {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const fetchAdminReservations = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/reservations`, {
        headers: { 'x-admin-token': token }
      });
      if (response.status === 401) {
        onLogout();
        return;
      }
      if (!response.ok) {
        throw new Error('Impossible de charger les réservations.');
      }
      const data = await response.json();
      setReservations(data);
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
    } finally {
      setLoading(false);
    }
  }, [token, onLogout]);

  useEffect(() => {
    fetchAdminReservations();
  }, [fetchAdminReservations]);

  const handleLogout = async () => {
    try {
      await fetch(`${API_BASE}/api/admin/logout`, {
        method: 'POST',
        headers: { 'x-admin-token': token }
      });
    } catch (error) {
      console.warn('Déconnexion admin non transmise:', error.message);
    } finally {
      onLogout();
    }
  };

  const totalRevenue = useMemo(
    () => reservations.reduce((sum, item) => sum + Number(item.price_paid || 0), 0),
    [reservations]
  );

  return (
    <div className="admin-shell">
      <header className="admin-header">
        <div>
          <p className="login-greeting">Touristique Express</p>
          <h1>Espace administrateur</h1>
        </div>
        <div className="header-actions">
          <button className="ghost" onClick={fetchAdminReservations}>
            Rafraîchir
          </button>
          <button className="ghost" onClick={handleLogout}>
            Déconnexion
          </button>
        </div>
      </header>
      {feedback && <div className={`feedback ${feedback.type}`}>{feedback.text}</div>}
      <section className="admin-stats">
        <div className="stat-card">
          <p>Total réservations</p>
          <strong>{reservations.length}</strong>
        </div>
        <div className="stat-card">
          <p>Revenus estimés</p>
          <strong>{formatPrice(totalRevenue)}</strong>
        </div>
      </section>
      <section className="admin-table">
        <h2>Historique des réservations</h2>
        {loading ? (
          <p>Chargement...</p>
        ) : reservations.length === 0 ? (
          <p>Aucune réservation pour le moment.</p>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Passager</th>
                  <th>Itinéraire</th>
                  <th>Départ</th>
                  <th>Contact</th>
                  <th>Paiement</th>
                  <th>Statut</th>
                </tr>
              </thead>
              <tbody>
                {reservations.map((item) => (
                  <tr key={item.id}>
                    <td>
                      {item.first_name} {item.last_name}
                      <br />
                      <small>{item.email}</small>
                    </td>
                    <td>
                      {item.origin} → {item.destination}
                    </td>
                    <td>
                      {formatDate(item.travel_date)} • {formatTime(item.departure_time)}
                    </td>
                    <td>{item.phone_number || 'n/a'}</td>
                    <td>
                      {item.payment_method}
                      <br />
                      <strong>{formatPrice(item.price_paid)}</strong>
                    </td>
                    <td>
                      <span className={`badge status-${item.status.toLowerCase()}`}>{item.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(() => {
    if (typeof window === 'undefined') return null;
    const cached = localStorage.getItem('touristique_user');
    return cached ? JSON.parse(cached) : null;
  });
  const [searchParams, setSearchParams] = useState(null);
  const [adminToken, setAdminToken] = useState(() => {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('touristique_admin_token');
  });
  const [portal, setPortal] = useState(() => {
    if (typeof window === 'undefined') return 'client';
    return window.location.pathname.startsWith('/admin') ? 'admin' : 'client';
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('touristique_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('touristique_user');
    }
  }, [user]);

  useEffect(() => {
    if (adminToken) {
      localStorage.setItem('touristique_admin_token', adminToken);
    } else {
      localStorage.removeItem('touristique_admin_token');
    }
  }, [adminToken]);

  useEffect(() => {
    const handlePopState = () => {
      const mode = window.location.pathname.startsWith('/admin') ? 'admin' : 'client';
      setPortal(mode);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleLogout = () => {
    setUser(null);
    setSearchParams(null);
  };

  const handleAdminLogout = () => {
    setAdminToken(null);
    if (typeof window !== 'undefined') {
      window.history.pushState(null, '', '/admin');
      setPortal('admin');
    }
  };

  return (
    <div className="app">
      {portal === 'admin' ? (
        adminToken ? (
          <AdminDashboard token={adminToken} onLogout={handleAdminLogout} />
        ) : (
          <AdminLogin
            onSuccess={(token) => {
              setAdminToken(token);
              if (typeof window !== 'undefined') {
                window.history.pushState(null, '', '/admin');
                setPortal('admin');
              }
            }}
            onBack={() => {
              window.history.pushState(null, '', '/');
              setPortal('client');
            }}
          />
        )
      ) : !user ? (
        <AuthSection
          onSuccess={(connectedUser) => {
            setUser(connectedUser);
            setSearchParams(null);
          }}
        />
      ) : !searchParams ? (
        <TravelSearch user={user} onLogout={handleLogout} onConfirm={(params) => setSearchParams(params)} />
      ) : (
        <Dashboard
          user={user}
          searchParams={searchParams}
          onResetSearch={() => setSearchParams(null)}
          onLogout={handleLogout}
        />
      )}
    </div>
  );
}

export default App;
